﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using System.Web.Http;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Net.Http.Headers;
using FoodHoodDataLibrary;
using Microsoft.AspNetCore.Mvc;
using System.Data.Entity.Infrastructure;

namespace FoodHoodServiceProvider.Controllers
{
    public class UserAddressController : ApiController
    {

        [HttpGet]
        [Route("api/UserAddress/Retrieve/{UserID}")]
        public async Task<IEnumerable<UserAddress>> Get(int UserID)
        {

            //var localFilePath = HttpContext.Current.Server.MapPath("~/Uploads/" + "download_4.jpeg");


            //FoodItem FI1 = new FoodItem() { FoodItemID = 1, FoodItemName = "Paneer Tikka Masala", FoodItemDescription = "Indian cheese curry", FoodItemImageUri = "Uploads/Restaurant-Style-Recipe-Paneer-Tikka_1.jpg" };//  FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI2 = new FoodItem() { FoodItemID = 2, FoodItemName = "Noodles", FoodItemDescription = "Chinese veg noodles", FoodItemImageUri = "Uploads/images(3).jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI3 = new FoodItem() { FoodItemID = 3, FoodItemName = "Burger", FoodItemDescription = "Ham burger", FoodItemImageUri = "Uploads/images(2).jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI4 = new FoodItem() { FoodItemID = 4, FoodItemName = "Pizza", FoodItemDescription = "New york style Pizza", FoodItemImageUri = "Uploads/images(1).jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI5 = new FoodItem() { FoodItemID = 5, FoodItemName = "Kaara kozhambu", FoodItemDescription = "South India authentic dish", FoodItemImageUri = "Uploads/images.jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };

            //List<FoodItem> FIL = new List<FoodItem>();
            //FIL.Add(FI1);
            //FIL.Add(FI2);
            //FIL.Add(FI3);
            //FIL.Add(FI4);
            //FIL.Add(FI5);


            using (FoodHoodEntities fhe = new FoodHoodEntities())
            {
                return fhe.UserAddresses.Where(a=>a.UserID==UserID).ToList();

            }

            //return FIL.ToList();

        }

        //[HttpGet]
        //[Route("api/UserAddress/Retrieve/{UserID}/{UserAddressID}")]
        //public async Task<UserAddress> GetUserAddress(int UserAddressID)
        //{
        //    using (FoodHoodEntities fhe = new FoodHoodEntities())
        //    {
        //        return fhe.UserAddresses.Where(fi => fi.UserAddressID == UserAddressID).SingleOrDefault();

        //    }
        //}



        [HttpPost]
        [Route("api/UserAddress/AddUserAddress")]
        public async Task<bool> PostUserAddress(UserAddress userAddress)
        {
            //_context.Item.Add(item);
            //await _context.SaveChangesAsync();

            //return CreatedAtAction("GetItem", new { id = item.ItemID }, item);


            using (FoodHoodEntities fhe = new FoodHoodEntities())
            {
                try
                {
                    fhe.UserAddresses.Add(userAddress);
                    await fhe.SaveChangesAsync();
                }
                catch(Exception ex)
                {
                    return false;
                }

                return true;

            }
        }


        [HttpPut]
        [Route("api/UserAddress/Update{UserAddressID}")]
        public async Task<bool> PutUserAddress(int UserAddressID, UserAddress useraddress)
        {
            if (UserAddressID != useraddress.UserAddressID)
            {
                return false;
            }
            using (FoodHoodEntities fhe = new FoodHoodEntities())
            {
                //_context.Entry(store).State = EntityState.Modified;
                fhe.Entry(useraddress).State = System.Data.Entity.EntityState.Modified;

                try
                {
                    // await _context.SaveChangesAsync();
                    await fhe.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserAddressExists(UserAddressID))
                    {
                        return false;
                    }
                    else
                    {
                        throw;
                    }
                }

                return true;
                
            }
        }

        [HttpDelete]
        [Route("api/UserAddress/Remove{UserAddressID}")]
        public async Task<UserAddress> DeleteUserAddress(int UserAddressID)
        {

            using (FoodHoodEntities fhe = new FoodHoodEntities())
            {
                var SelectedUserAddress = await fhe.UserAddresses.FindAsync(UserAddressID); //.FirstOrDefault(x => x.StoreID == id);

                fhe.UserAddresses.Remove(SelectedUserAddress); //.FirstOrDefault(x => x.StoreID == id);

                await fhe.SaveChangesAsync();

                return SelectedUserAddress;

            }
        }


        private bool UserAddressExists(int UserAddressID)
        {
            using (FoodHoodEntities fhe = new FoodHoodEntities())
            {
                return fhe.UserAddresses.Any(x => x.UserAddressID == UserAddressID);

            }

        }
    }






    //public class FoodItem
    //{
    //    public int FoodItemID { get; set; }
    //    public string FoodItemName { get; set; }
    //    public string FoodItemDescription { get; set; }
    //    //public string FoodItemImage { get; set; }
    //    public string FoodItemImageUri { get; set; }

    //}
}