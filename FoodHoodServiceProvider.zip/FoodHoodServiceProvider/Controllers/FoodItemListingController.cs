﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using System.Web.Http;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Net.Http.Headers;
using FoodHoodDataLibrary;

namespace FoodHoodServiceProvider.Controllers
{
    public class FoodItemListingController : ApiController
    {
        //[HttpGet]
        //[Route("api/FoodItem/Retrieve")]
        //public List<FoodItem> Get()
        //{

        //    var localFilePath = HttpContext.Current.Server.MapPath("~/Uploads/" + "download_4.jpeg");


        //    FoodItem FI1 = new FoodItem() { FoodItemID =1, FoodItemName="Paneer Tikka Masala 1", FoodItemDescription="Indian cheese curry 1",FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI2 = new FoodItem() { FoodItemID = 2, FoodItemName = "Paneer Tikka Masala 2", FoodItemDescription = "Indian cheese curry 2", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI3 = new FoodItem() { FoodItemID = 3, FoodItemName = "Paneer Tikka Masala 3", FoodItemDescription = "Indian cheese curry 3", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI4 = new FoodItem() { FoodItemID = 4, FoodItemName = "Paneer Tikka Masala 4", FoodItemDescription = "Indian cheese curry 4", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI5 = new FoodItem() { FoodItemID = 5, FoodItemName = "Paneer Tikka Masala 5", FoodItemDescription = "Indian cheese curry 5", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };

        //    List<FoodItem> FIL = new List<FoodItem>();
        //    FIL.Add(FI1);
        //    FIL.Add(FI2);
        //    FIL.Add(FI3);
        //    FIL.Add(FI4);
        //    FIL.Add(FI5);

        //    return FIL;

        //}


        //public HttpResponseMessage Get1()
        //{

        //    var localFilePath = HttpContext.Current.Server.MapPath("~/Uploads/" + "download_4.jpeg");


        //    FoodItem FI1 = new FoodItem() { FoodItemID = 1, FoodItemName = "Paneer Tikka Masala 1", FoodItemDescription = "Indian cheese curry 1", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI2 = new FoodItem() { FoodItemID = 2, FoodItemName = "Paneer Tikka Masala 2", FoodItemDescription = "Indian cheese curry 2", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI3 = new FoodItem() { FoodItemID = 3, FoodItemName = "Paneer Tikka Masala 3", FoodItemDescription = "Indian cheese curry 3", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI4 = new FoodItem() { FoodItemID = 4, FoodItemName = "Paneer Tikka Masala 4", FoodItemDescription = "Indian cheese curry 4", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };
        //    FoodItem FI5 = new FoodItem() { FoodItemID = 5, FoodItemName = "Paneer Tikka Masala 5", FoodItemDescription = "Indian cheese curry 5", FoodItemImage = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read)) };

        //    List<FoodItem> FIL = new List<FoodItem>();
        //    FIL.Add(FI1);
        //    FIL.Add(FI2);
        //    FIL.Add(FI3);
        //    FIL.Add(FI4);
        //    FIL.Add(FI5);

        //    return Request.CreateResponse(HttpStatusCode.OK, FIL.ToList());

        //}


        [HttpGet]
        [Route("api/FoodItemListing/Retrieve")]
        public async Task<IEnumerable<FoodItem>> Get()
        {

            //var localFilePath = HttpContext.Current.Server.MapPath("~/Uploads/" + "download_4.jpeg");


            //FoodItem FI1 = new FoodItem() { FoodItemID = 1, FoodItemName = "Paneer Tikka Masala", FoodItemDescription = "Indian cheese curry", FoodItemImageUri = "Uploads/Restaurant-Style-Recipe-Paneer-Tikka_1.jpg" };//  FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI2 = new FoodItem() { FoodItemID = 2, FoodItemName = "Noodles", FoodItemDescription = "Chinese veg noodles", FoodItemImageUri = "Uploads/images(3).jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI3 = new FoodItem() { FoodItemID = 3, FoodItemName = "Burger", FoodItemDescription = "Ham burger", FoodItemImageUri = "Uploads/images(2).jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI4 = new FoodItem() { FoodItemID = 4, FoodItemName = "Pizza", FoodItemDescription = "New york style Pizza", FoodItemImageUri = "Uploads/images(1).jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };
            //FoodItem FI5 = new FoodItem() { FoodItemID = 5, FoodItemName = "Kaara kozhambu", FoodItemDescription = "South India authentic dish", FoodItemImageUri = "Uploads/images.jpeg" };// FoodItemImage = new FileStream(localFilePath, FileMode.Open, FileAccess.Read) };

            //List<FoodItem> FIL = new List<FoodItem>();
            //FIL.Add(FI1);
            //FIL.Add(FI2);
            //FIL.Add(FI3);
            //FIL.Add(FI4);
            //FIL.Add(FI5);


            using (FoodHoodEntities fhe = new FoodHoodEntities())
            {
                return fhe.FoodItems.ToList();

            }

            //return FIL.ToList();

        }


        [HttpPost]
        [Route("api/FoodItemListing/AddFoodListing")]
        public async Task<bool> PostFoodItemListing(FoodListing fl)
        {
            try
            {
                using (FoodHoodEntities fhe = new FoodHoodEntities())
                {
                    fhe.FoodListings.Add(fl);

                    await fhe.SaveChangesAsync();

                    return true;
                }
            }
            catch(Exception ex)
            {
                return false;
            }


            
        }
    }



        //public class FoodItem
        //{
        //    public int FoodItemID { get; set; }
        //    public string FoodItemName { get; set; }
        //    public string FoodItemDescription { get; set; }
        //    //public string FoodItemImage { get; set; }
        //    public string FoodItemImageUri { get; set; }

        //}
    }