﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using System.Web.Http;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Net.Http.Headers;


namespace FoodHoodServiceProvider.Controllers
{
    public class UploadsController : ApiController
    {
        [Route("api/Files/Upload")]
        public async Task<string> Post()
        {
            try
            {
                var httpRequest = HttpContext.Current.Request;

                if (httpRequest.Files.Count > 0)
                {
                    foreach (string file in httpRequest.Files)
                    {
                        var postedFile = httpRequest.Files[file];
                        var fileName = postedFile.FileName.Split('\\').LastOrDefault().Split('/').LastOrDefault();
                        var filePath = HttpContext.Current.Server.MapPath("~/Uploads/" + fileName);
                        postedFile.SaveAs(filePath);
                        return "Uploads/" + fileName;
                    }
                }
                return "";
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        [HttpGet]
        [Route("api/Files/Download")]
        public HttpResponseMessage GetFile()
        {
            //if (String.IsNullOrEmpty(id))
            //    return Request.CreateResponse(HttpStatusCode.BadRequest);

            string fileName;
            //string localFilePath;
            int fileSize;

            //localFilePath = "/Uploads/download_4.jpeg"; //getFileFromID(id, out fileName, out fileSize);
            var localFilePath = HttpContext.Current.Server.MapPath("~/Uploads/" + "download_4.jpeg");


            
            //classresponse cr = new classresponse();
            //cr.FileName = "download_4.jpeg";
            //cr.FileContent = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read));

            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK);
            response.Content = new StreamContent(new FileStream(localFilePath, FileMode.Open, FileAccess.Read));
            response.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "download_4.jpeg";
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");

            return response;
        }

        class classresponse
        {
            public string FileName { get; set; }
            public StreamContent FileContent { get; set; }
        }


      

        }
}